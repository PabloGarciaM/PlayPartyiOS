//
//  ViewController.swift
//  PlayParty
//
//  Created by Jose Francisco Murillo Lozano on 24/11/20.
//

import UIKit

class TabBarController: UITabBarController {

    @IBOutlet weak var bar: UITabBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }


}

